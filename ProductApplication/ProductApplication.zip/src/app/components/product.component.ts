import { Component } from '@angular/core';
import { ProductService } from '../services/product.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Product } from '../model/Product';

@Component({
    selector: 'app-product',
    templateUrl: './product.component.html',
    styleUrls: ['./product.component.css']
})
export class ProductComponent {
    // tslint:disable-next-line:prefer-const
    public result: any;
    public product: Product = new Product();
    constructor(public service: ProductService) {}
    // tslint:disable-next-line:use-lifecycle-interface
    ngOnInit() {
        this.getAll();
    }
    public getAll() {
        this.service.getAllProducts().subscribe((success) => {
            this.result = success;
        }, (error: HttpErrorResponse) => {
            console.log(error);
        });
    }
    public getProduct(productId: string): any {
        this.service.getProduct(productId).subscribe((success) => {
            this.product = success;
            console.log(this.product);
        }, (error: HttpErrorResponse) => {
            console.log(error);
        });
    }

    public updateProduct(product: Product) {
        this.service.updateProduct(product.productId, product).subscribe((success) => {
            this.product = success;
            console.log(this.product);
            this.getAll();
        }, (error: HttpErrorResponse) => {
            console.log(error);
        });
    }

    public addProduct(product: Product) {
        this.service.addProduct(product).subscribe((success) => {
            console.log(success);
            this.getAll();
        }, (error: HttpErrorResponse) => {
            console.log(error);
        });
    }

    public removeProduct(productId: string) {
        this.service.deleteProduct(productId).subscribe((success) => {
            console.log(success);
            this.getAll();
        }, (error: HttpErrorResponse) => {
            console.log(error);
        });
    }
}
