export class Product {
    public productId: string;
    public productName: string;
    public price: number;

}
