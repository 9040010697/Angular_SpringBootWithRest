import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import {Product} from '../model/Product';

@Injectable({
    providedIn: 'root'
})
export class ProductService {
    private baseUrl = `http://localhost:8085`;

    constructor(public httpClient: HttpClient) {}

    public getAllProducts(): Observable<any> {
        const productGet = this.baseUrl + '/product/get';
        return this.httpClient.get(productGet);
    }

    public getProduct(productId: string): Observable<any> {
        const productGet = this.baseUrl + `/product/get/${productId}`;
        return this.httpClient.get(productGet);
    }

    public addProduct(product: Product): Observable<any> {
        const productAdd = this.baseUrl + '/product/add';
        return this.httpClient.post(productAdd, product);
    }

    public updateProduct(productId: string, product: Product): Observable<any> {
        const productUpdate = this.baseUrl + `/product/update/${productId}`;
        return this.httpClient.put(productUpdate, product);
    }

    public deleteProduct(productId: string): Observable<any> {
        const productDelete = this.baseUrl + `/product/delete/${productId}`;
        return this.httpClient.delete(productDelete);
    }
}
